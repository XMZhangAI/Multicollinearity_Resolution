%导入数据 
clc;
clear all;
close all;
data = load('data1.csv');

x = data(1:end-1, :);  % 从第 2 列开始是自变量
y = log(data(end, :))';      % 第 1 列是因变量 
x0=ones(8,1);
x1= log(x(1,:))';
x2= log(x(2,:))';
x3= log(x(3,:))';
x4= log(x(4,:))';
x5= log(x(5,:))';
x6= log(x(6,:))';
x7= log(x(7,:))';
x8= log(x(8,:))';
x9= log(x(9,:))';
X=[ones(size(y)),x1,x2, x3, x4, x5,x6,x7,x8,x9];  
% 导入数据或生成自变量矩阵 X，其中每一列是一个自变量
X1 = [x0,x1, x2, x3, x4,x5,x6,x7,x8,x9];  % 自变量矩阵
size(X1, 1)
% 进行岭回归分析
[B] = ridge(y, X1, alpha);
X2=[ones(size(X1, 1), 1), X1];
% 输出结果
disp('岭回归系数：');
disp(B);
% 计算预测值
y_pred =  X1 * B;

% 计算均方误差（MSE）
mse = mean((y - y_pred).^2);



% 可视化拟合效果
figure;
scatter(y, y_pred);
xlabel('实际观测值');
ylabel('预测值');
title('拟合效果');
% 计算总平方和
SST = sum((y - mean(y)).^2);

% 计算残差平方和
SSE = sum((y - y_pred).^2);

% 计算决定系数
R_squared = 1 - SSE / SST;

% 输出决定系数
disp(['决定系数 R^2：', num2str(R_squared)]);
% 输出结果
disp(['均方误差（MSE）：', num2str(mse)]);


% disp('自由度调整的决定系数（adjusted R-squared）：');
% disp(FitInfo.AdjustedR2);

% %开始分析  
% [b,bint,r,rint,stats] = regress(y,X)
% 
% 
% % 计算 VIF
% vif_values = vif(X1);
% 
% 
% %b储存的是系数
% %bint储存的是系数的区间值，我们叫做置信区间，就是说是系数可能存在的范围，区间范围越小越好
% %r是误差,也叫残差，rint是误差的区间
% %stats分别对应4个检验，R?检验值、F检验值、p、绝对误差的方差s?
% %R?越接近1说明拟合程度越好，F这个要查表，p这个一般小于0.05就可以了，s?越小越好
% %F小于标准值说明拟合结果和原数据相差不大，可接受
% 
% rcoplot(r,rint);%作残差分析图
% title('残差图的绘制');
% xlabel('数据');
% ylabel('残差');
% 
% 
% 
% 
% function vif_values = vif(X)
%     [~, num_vars] = size(X);  % 获取自变量的数量
%     vif_values = zeros(1, num_vars);  % 初始化 VIF 数组
%     
%     for i = 1:num_vars
%         X_i = X(:, i);  % 当前自变量
%         X_without_i = X(:, [1:i-1, i+1:end]);  % 去除当前自变量的其他自变量
%         lm = fitlm(X_without_i, X_i);  % 拟合线性模型
%         vif_values(i) = 1 / (1 - lm.Rsquared.Ordinary);  % 计算 VIF
%     end
% end
